package com.autoclicker.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View

class PickResult(
    val x1: Int, val y1: Int, val x2: Int, val y2: Int,
    val dur: Long, val t0: Long, val t1: Long
)

/** Полноэкранный прозрачный слой: показывает перекрестие и координаты, сообщает о жесте. */
class PickView(
    ctx: Context,
    private val showLine: Boolean,
    private val hint: String,
    private val onUp: (PickResult) -> Unit
) : View(ctx) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loc = IntArray(2)
    private var dx = 0f
    private var dy = 0f
    private var tx = -1f
    private var ty = -1f
    private var t0 = 0L
    private var down = false

    var active: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var hideMarks: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dx = e.rawX
                dy = e.rawY
                tx = dx
                ty = dy
                t0 = e.eventTime
                down = true
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                tx = e.rawX
                ty = e.rawY
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                tx = e.rawX
                ty = e.rawY
                down = false
                invalidate()
                onUp(PickResult(dx.toInt(), dy.toInt(), tx.toInt(), ty.toInt(), e.eventTime - t0, t0, e.eventTime))
            }
            MotionEvent.ACTION_CANCEL -> {
                down = false
                invalidate()
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        if (!active || hideMarks) return
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        val w = width.toFloat()
        val h = height.toFloat()
        val d1 = context.dp(1).toFloat()

        p.style = Paint.Style.FILL
        p.color = 0x26000000
        c.drawRect(0f, 0f, w, h, p)

        p.textAlign = Paint.Align.CENTER
        if (!down) {
            p.color = Color.WHITE
            p.textSize = d1 * 18
            p.setShadowLayer(8f, 0f, 0f, Color.BLACK)
            c.drawText(hint, w / 2, h * 0.2f, p)
            p.clearShadowLayer()
        }

        if (tx >= 0f) {
            val cx = tx - ox
            val cy = ty - oy
            p.color = ACCENT
            if (showLine && down) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = d1 * 3
                c.drawLine(dx - ox, dy - oy, cx, cy, p)
                p.style = Paint.Style.FILL
                c.drawCircle(dx - ox, dy - oy, d1 * 6, p)
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = d1 * 2
            c.drawCircle(cx, cy, d1 * 24, p)
            c.drawLine(cx - d1 * 40, cy, cx + d1 * 40, cy, p)
            c.drawLine(cx, cy - d1 * 40, cx, cy + d1 * 40, p)

            p.style = Paint.Style.FILL
            p.color = Color.WHITE
            p.textSize = d1 * 18
            p.setShadowLayer(8f, 0f, 0f, Color.BLACK)
            val ly = if (cy < d1 * 110) cy + d1 * 70 else cy - d1 * 52
            c.drawText(tx.toInt().toString() + ", " + ty.toInt().toString(), cx, ly, p)
            p.clearShadowLayer()
        }
    }
}
