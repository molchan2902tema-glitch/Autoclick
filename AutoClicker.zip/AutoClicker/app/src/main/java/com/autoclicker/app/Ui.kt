package com.autoclicker.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View

const val PREFS = "ac"
const val KEY_INTERVAL = "interval"

val BG = 0xFF0F1115.toInt()
val CARD = 0xFF171B22.toInt()
val ACCENT = 0xFF3DDC84.toInt()
val DANGER = 0xFFEF4444.toInt()
val MUTED = 0xFF8A93A3.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun roundBg(color: Int, radius: Float) = GradientDrawable().apply {
    setColor(color); cornerRadius = radius
}

fun ovalBg(color: Int) = GradientDrawable().apply {
    shape = GradientDrawable.OVAL; setColor(color)
}

/** Нажатие с анимацией, без системной подсветки. */
@Suppress("ClickableViewAccessibility")
fun View.pressable(onClick: () -> Unit) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(.93f).scaleY(.93f).setDuration(80).start()
            MotionEvent.ACTION_UP -> {
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                if (e.x in 0f..v.width.toFloat() && e.y in 0f..v.height.toFloat()) onClick()
            }
            MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        true
    }
}

class IconView(ctx: Context, var kind: Kind, private val tint: Int) : View(ctx) {
    enum class Kind { PLAY, PAUSE, CLOSE, TARGET, GRIP }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2; val s = minOf(w, h)
        p.color = tint; p.alpha = 255
        p.strokeCap = Paint.Cap.ROUND
        when (kind) {
            Kind.PLAY -> {
                p.style = Paint.Style.FILL
                path.reset()
                path.moveTo(cx - s * .12f, cy - s * .2f)
                path.lineTo(cx + s * .22f, cy)
                path.lineTo(cx - s * .12f, cy + s * .2f)
                path.close()
                c.drawPath(path, p)
            }
            Kind.PAUSE -> {
                p.style = Paint.Style.FILL
                val r = s * .03f
                rect.set(cx - s * .16f, cy - s * .2f, cx - s * .06f, cy + s * .2f)
                c.drawRoundRect(rect, r, r, p)
                rect.set(cx + s * .06f, cy - s * .2f, cx + s * .16f, cy + s * .2f)
                c.drawRoundRect(rect, r, r, p)
            }
            Kind.CLOSE -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = s * .07f
                val d = s * .14f
                c.drawLine(cx - d, cy - d, cx + d, cy + d, p)
                c.drawLine(cx + d, cy - d, cx - d, cy + d, p)
            }
            Kind.TARGET -> {
                p.style = Paint.Style.FILL; p.alpha = 45
                c.drawCircle(cx, cy, s * .46f, p)
                p.alpha = 255; p.style = Paint.Style.STROKE; p.strokeWidth = s * .06f
                c.drawCircle(cx, cy, s * .42f, p)
                val a = s * .2f; val b = s * .32f
                c.drawLine(cx, cy - b, cx, cy - a, p)
                c.drawLine(cx, cy + a, cx, cy + b, p)
                c.drawLine(cx - b, cy, cx - a, cy, p)
                c.drawLine(cx + a, cy, cx + b, cy, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, s * .07f, p)
            }
            Kind.GRIP -> {
                p.style = Paint.Style.FILL
                for (i in -1..1) {
                    c.drawCircle(cx - s * .17f, cy + i * s * .3f, s * .06f, p)
                    c.drawCircle(cx + s * .17f, cy + i * s * .3f, s * .06f, p)
                }
            }
        }
    }
}
