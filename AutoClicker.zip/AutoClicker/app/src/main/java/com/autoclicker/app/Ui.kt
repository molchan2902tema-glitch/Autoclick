package com.autoclicker.app

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

const val PREFS = "ac"
const val KEY_INTERVAL = "interval"

val BG = 0xFF0F1115.toInt()
val CARD = 0xFF171B22.toInt()
val FIELD = 0xFF222833.toInt()
val ACCENT = 0xFF3DDC84.toInt()
val ONACCENT = 0xFF06210F.toInt()
val DANGER = 0xFFEF4444.toInt()
val MUTED = 0xFF8A93A3.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun roundBg(color: Int, radius: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radius
    return g
}

fun ovalBg(color: Int): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.OVAL
    g.setColor(color)
    return g
}

fun Context.txt(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
    val v = TextView(this)
    v.text = t
    v.textSize = sp
    v.setTextColor(color)
    if (bold) v.typeface = Typeface.DEFAULT_BOLD
    return v
}

fun Context.pill(label: String, fg: Int, bg: Int, h: Int): TextView {
    val v = TextView(this)
    v.text = label
    v.textSize = 15f
    v.setTextColor(fg)
    v.typeface = Typeface.DEFAULT_BOLD
    v.gravity = Gravity.CENTER
    v.background = roundBg(bg, dp(h / 2).toFloat())
    v.minHeight = dp(h)
    return v
}

/** Нажатие с анимацией и необязательным долгим нажатием. Без системной подсветки. */
@Suppress("ClickableViewAccessibility")
fun View.pressable(onLong: (() -> Unit)? = null, onClick: () -> Unit) {
    var longFired = false
    val longRun = Runnable {
        longFired = true
        animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        onLong?.invoke()
    }
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                longFired = false
                v.animate().scaleX(.95f).scaleY(.95f).setDuration(80).start()
                if (onLong != null) v.postDelayed(longRun, 500)
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.x < 0f || e.y < 0f || e.x > v.width || e.y > v.height) v.removeCallbacks(longRun)
            }
            MotionEvent.ACTION_UP -> {
                v.removeCallbacks(longRun)
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                if (!longFired && e.x >= 0f && e.y >= 0f && e.x <= v.width && e.y <= v.height) onClick()
            }
            MotionEvent.ACTION_CANCEL -> {
                v.removeCallbacks(longRun)
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
        }
        true
    }
}

class IconView(ctx: Context, var kind: Kind, private val tint: Int) : View(ctx) {
    enum class Kind { PLAY, PAUSE, CLOSE, TARGET, GRIP, BACK, PLUS }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2
        val cy = h / 2
        val s = minOf(w, h)
        p.color = tint
        p.alpha = 255
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        when (kind) {
            Kind.PLAY -> {
                p.style = Paint.Style.FILL
                path.reset()
                path.moveTo(cx - s * .12f, cy - s * .2f)
                path.lineTo(cx + s * .22f, cy)
                path.lineTo(cx - s * .12f, cy + s * .2f)
                path.close()
                c.drawPath(path, p)
            }
            Kind.PAUSE -> {
                p.style = Paint.Style.FILL
                val r = s * .03f
                rect.set(cx - s * .16f, cy - s * .2f, cx - s * .06f, cy + s * .2f)
                c.drawRoundRect(rect, r, r, p)
                rect.set(cx + s * .06f, cy - s * .2f, cx + s * .16f, cy + s * .2f)
                c.drawRoundRect(rect, r, r, p)
            }
            Kind.CLOSE -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * .07f
                val d = s * .14f
                c.drawLine(cx - d, cy - d, cx + d, cy + d, p)
                c.drawLine(cx + d, cy - d, cx - d, cy + d, p)
            }
            Kind.BACK -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * .07f
                path.reset()
                path.moveTo(cx + s * .08f, cy - s * .18f)
                path.lineTo(cx - s * .1f, cy)
                path.lineTo(cx + s * .08f, cy + s * .18f)
                c.drawPath(path, p)
            }
            Kind.PLUS -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * .07f
                c.drawLine(cx - s * .16f, cy, cx + s * .16f, cy, p)
                c.drawLine(cx, cy - s * .16f, cx, cy + s * .16f, p)
            }
            Kind.TARGET -> {
                p.style = Paint.Style.FILL
                p.alpha = 45
                c.drawCircle(cx, cy, s * .46f, p)
                p.alpha = 255
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * .06f
                c.drawCircle(cx, cy, s * .42f, p)
                val a = s * .2f
                val b = s * .32f
                c.drawLine(cx, cy - b, cx, cy - a, p)
                c.drawLine(cx, cy + a, cx, cy + b, p)
                c.drawLine(cx - b, cy, cx - a, cy, p)
                c.drawLine(cx + a, cy, cx + b, cy, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, s * .07f, p)
            }
            Kind.GRIP -> {
                p.style = Paint.Style.FILL
                for (i in -1..1) {
                    c.drawCircle(cx - s * .17f, cy + i * s * .3f, s * .06f, p)
                    c.drawCircle(cx + s * .17f, cy + i * s * .3f, s * .06f, p)
                }
            }
        }
    }
}

// ---------- Диалоги ----------

fun Activity.sheetDialog(title: String, build: (LinearLayout, Dialog) -> Unit): Dialog {
    val d = Dialog(this)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.background = roundBg(CARD, dp(24).toFloat())
    box.setPadding(dp(22), dp(20), dp(22), dp(16))
    val t = txt(title, 18f, Color.WHITE, true)
    t.setPadding(0, 0, 0, dp(10))
    box.addView(t)
    build(box, d)
    d.setContentView(box)
    val win = d.window
    if (win != null) {
        win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        win.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        win.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    }
    d.show()
    return d
}

fun Activity.addButtons(
    box: LinearLayout, d: Dialog, okLabel: String, okBg: Int, okFg: Int,
    neutral: String?, onNeutral: (() -> Unit)?, onOk: () -> Unit
) {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(0, dp(18), 0, 0)
    if (neutral != null) {
        val n = pill(neutral, DANGER, 0x00000000, 44)
        n.setPadding(dp(12), 0, dp(12), 0)
        n.pressable {
            d.dismiss()
            if (onNeutral != null) onNeutral()
        }
        row.addView(n, LinearLayout.LayoutParams(-2, dp(44)))
    }
    row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
    val c = pill("Отмена", MUTED, 0x00000000, 44)
    c.setPadding(dp(12), 0, dp(12), 0)
    c.pressable { d.dismiss() }
    row.addView(c, LinearLayout.LayoutParams(-2, dp(44)))
    val ok = pill(okLabel, okFg, okBg, 44)
    ok.setPadding(dp(22), 0, dp(22), 0)
    ok.pressable {
        d.dismiss()
        onOk()
    }
    val okLp = LinearLayout.LayoutParams(-2, dp(44))
    okLp.marginStart = dp(8)
    row.addView(ok, okLp)
    box.addView(row)
}

fun Activity.styledEdit(initial: String, numeric: Boolean): EditText {
    val et = EditText(this)
    et.setText(initial)
    et.setTextColor(Color.WHITE)
    et.textSize = 16f
    et.inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
    et.background = roundBg(FIELD, dp(12).toFloat())
    et.setPadding(dp(14), dp(10), dp(14), dp(10))
    et.setSelectAllOnFocus(true)
    et.highlightColor = 0x553DDC84
    return et
}

fun Activity.showFields(
    title: String, labels: List<String>, values: List<Int>,
    neutral: String? = null, onNeutral: (() -> Unit)? = null,
    onOk: (List<Int>) -> Unit
) {
    val edits = ArrayList<EditText>()
    sheetDialog(title) { box, d ->
        for (i in labels.indices) {
            val l = txt(labels[i], 13f, MUTED)
            l.setPadding(0, dp(8), 0, dp(4))
            box.addView(l)
            val et = styledEdit(values[i].toString(), true)
            edits.add(et)
            box.addView(et)
        }
        addButtons(box, d, "Готово", ACCENT, ONACCENT, neutral, onNeutral) {
            val out = ArrayList<Int>()
            for (i in edits.indices) out.add(edits[i].text.toString().toIntOrNull() ?: values[i])
            onOk(out)
        }
    }
}

fun Activity.askText(title: String, initial: String, onOk: (String) -> Unit) {
    sheetDialog(title) { box, d ->
        val et = styledEdit(initial, false)
        box.addView(et)
        addButtons(box, d, "Готово", ACCENT, ONACCENT, null, null) {
            val s = et.text.toString().trim()
            if (s.isNotEmpty()) onOk(s)
        }
    }
}

fun Activity.confirmDialog(title: String, message: String, okLabel: String, onOk: () -> Unit) {
    sheetDialog(title) { box, d ->
        box.addView(txt(message, 14f, MUTED))
        addButtons(box, d, okLabel, DANGER, Color.WHITE, null, null, onOk)
    }
}
