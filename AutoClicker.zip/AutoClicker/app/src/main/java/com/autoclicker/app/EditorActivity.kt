package com.autoclicker.app

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class EditorActivity : Activity() {

    private var scriptId = 0L
    private lateinit var script: Script
    private lateinit var titleTv: TextView
    private lateinit var chip: TextView
    private lateinit var empty: TextView
    private lateinit var list: RecyclerView
    private val adapter = StepAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scriptId = intent.getLongExtra("id", 0L)
        val s = Store.get(this, scriptId)
        if (s == null) {
            finish()
            return
        }
        script = s
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (!::script.isInitialized) return
        val fresh = Store.get(this, scriptId)
        if (fresh != null) script = fresh
        adapter.notifyDataSetChanged()
        refreshHeader()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.enter, R.anim.exit)
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    private fun save() {
        val snap = script
        Store.update(this, scriptId) { s ->
            s.name = snap.name
            s.repeat = snap.repeat
            s.jitterPx = snap.jitterPx
            s.jitterPct = snap.jitterPct
            s.steps.clear()
            s.steps.addAll(snap.steps)
        }
    }

    private fun refreshHeader() {
        titleTv.text = script.name
        val rep = if (script.repeat == 0) "бесконечно" else "${script.repeat} раз"
        chip.text = "Повтор: $rep · разброс ${script.jitterPx} px / ${script.jitterPct}%"
        empty.visibility = if (script.steps.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(12), dp(44), dp(20), dp(4))
        val back = IconView(this, IconView.Kind.BACK, Color.WHITE)
        back.pressable { finish() }
        head.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        titleTv = txt("", 22f, Color.WHITE, true)
        titleTv.maxLines = 1
        titleTv.pressable { renameDialog() }
        head.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(head)

        chip = txt("", 13f, MUTED)
        chip.background = roundBg(FIELD, dp(16).toFloat())
        chip.setPadding(dp(14), dp(8), dp(14), dp(8))
        chip.pressable { settingsDialog() }
        val chipLp = LinearLayout.LayoutParams(-2, -2)
        chipLp.marginStart = dp(20)
        chipLp.topMargin = dp(4)
        chipLp.bottomMargin = dp(8)
        root.addView(chip, chipLp)

        val mid = FrameLayout(this)
        list = RecyclerView(this)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        list.clipToPadding = false
        list.setPadding(dp(16), dp(8), dp(16), dp(16))
        list.overScrollMode = View.OVER_SCROLL_NEVER
        mid.addView(list, FrameLayout.LayoutParams(-1, -1))
        empty = txt("Пока нет шагов\nНажмите «Запись» и выполните действия\nили добавьте шаг вручную", 15f, MUTED)
        empty.gravity = Gravity.CENTER
        mid.addView(empty, FrameLayout.LayoutParams(-1, -1))
        root.addView(mid, LinearLayout.LayoutParams(-1, 0, 1f))

        val touchCb = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, ItemTouchHelper.LEFT
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.adapterPosition
                val to = target.adapterPosition
                if (from < 0 || to < 0) return false
                val item = script.steps.removeAt(from)
                script.steps.add(to, item)
                adapter.notifyItemMoved(from, to)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val p = viewHolder.adapterPosition
                if (p < 0) return
                script.steps.removeAt(p)
                adapter.notifyItemRemoved(p)
                save()
                refreshHeader()
                list.post { adapter.notifyDataSetChanged() }
            }

            override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                super.clearView(recyclerView, viewHolder)
                save()
                recyclerView.post { adapter.notifyDataSetChanged() }
            }
        }
        ItemTouchHelper(touchCb).attachToRecyclerView(list)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(16), dp(8), dp(16), dp(28))
        val recBtn = pill("Запись", DANGER, CARD, 54)
        recBtn.pressable { startRecording() }
        val addBtn = pill("Шаг", Color.WHITE, CARD, 54)
        addBtn.pressable { showAdd() }
        val runBtn = pill("Запуск", ONACCENT, ACCENT, 54)
        runBtn.pressable { runScriptNow() }
        val l1 = LinearLayout.LayoutParams(0, dp(54), 1f)
        l1.marginEnd = dp(8)
        val l2 = LinearLayout.LayoutParams(0, dp(54), 1f)
        l2.marginEnd = dp(8)
        val l3 = LinearLayout.LayoutParams(0, dp(54), 1.3f)
        bar.addView(recBtn, l1)
        bar.addView(addBtn, l2)
        bar.addView(runBtn, l3)
        root.addView(bar)

        setContentView(root)
        refreshHeader()
    }

    // ---------- действия ----------

    private fun service(): ClickerService? {
        val svc = ClickerService.instance
        if (svc == null) toast("Сначала включите службу «Автокликер»")
        return svc
    }

    private fun startRecording() {
        val svc = service() ?: return
        svc.startRecord(scriptId)
        moveTaskToBack(true)
    }

    private fun runScriptNow() {
        if (script.steps.isEmpty()) {
            toast("Добавьте шаги")
            return
        }
        val svc = service() ?: return
        svc.runScript(scriptId)
        moveTaskToBack(true)
    }

    private fun pick(kind: String) {
        if (kind == T_COLOR && Build.VERSION.SDK_INT < 30) {
            toast("Нужен Android 11 или новее")
            return
        }
        val svc = service() ?: return
        svc.startPickStep(scriptId, kind)
        moveTaskToBack(true)
    }

    private fun addStep(s: Step) {
        script.steps.add(s)
        save()
        adapter.notifyItemInserted(script.steps.size - 1)
        list.scrollToPosition(script.steps.size - 1)
        refreshHeader()
    }

    private fun showAdd() {
        sheetDialog("Добавить шаг") { box, d ->
            fun row(title: String, sub: String, onClick: () -> Unit) {
                val r = LinearLayout(this)
                r.orientation = LinearLayout.VERTICAL
                r.background = roundBg(FIELD, dp(14).toFloat())
                r.setPadding(dp(16), dp(12), dp(16), dp(12))
                r.addView(txt(title, 16f, Color.WHITE, true))
                r.addView(txt(sub, 12f, MUTED))
                r.pressable {
                    d.dismiss()
                    onClick()
                }
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.bottomMargin = dp(8)
                box.addView(r, lp)
            }
            row("Тап", "Нажмите на экране в нужной точке") { pick(T_TAP) }
            row("Удержание", "Нажмите и держите нужное время") { pick(T_HOLD) }
            row("Свайп", "Проведите пальцем от точки к точке") { pick(T_SWIPE) }
            row("Пауза", "Подождать заданное время") {
                showFields("Пауза", listOf("Миллисекунд"), listOf(500)) { v ->
                    addStep(Step(T_WAIT, ms = v[0].coerceAtLeast(1)))
                }
            }
            row("Цикл", "Повторить последние шаги несколько раз") {
                if (script.steps.isEmpty()) {
                    toast("Сначала добавьте шаги")
                } else {
                    showFields(
                        "Цикл",
                        listOf("Повторов (0 = бесконечно)", "Сколько последних шагов повторять"),
                        listOf(3, 1)
                    ) { v ->
                        val k = v[1].coerceIn(1, script.steps.size)
                        script.steps.add(script.steps.size - k, Step(T_LOOP, n = v[0].coerceAtLeast(0)))
                        script.steps.add(Step(T_END))
                        save()
                        adapter.notifyDataSetChanged()
                        refreshHeader()
                    }
                }
            }
            row("Ждать цвет", "Продолжить, когда пиксель в точке станет нужного цвета") { pick(T_COLOR) }
        }
    }

    private fun changed(pos: Int) {
        save()
        adapter.notifyItemChanged(pos)
    }

    private fun duplicate(pos: Int) {
        script.steps.add(pos + 1, script.steps[pos].copyStep())
        save()
        adapter.notifyDataSetChanged()
        refreshHeader()
    }

    private fun editStep(pos: Int) {
        if (pos < 0 || pos >= script.steps.size) return
        val s = script.steps[pos]
        when (s.type) {
            T_TAP -> showFields("Тап", listOf("X", "Y"), listOf(s.x, s.y), "Дубль", { duplicate(pos) }) { v ->
                s.x = v[0]
                s.y = v[1]
                changed(pos)
            }
            T_HOLD -> showFields(
                "Удержание", listOf("X", "Y", "Время, мс"), listOf(s.x, s.y, s.ms), "Дубль", { duplicate(pos) }
            ) { v ->
                s.x = v[0]
                s.y = v[1]
                s.ms = v[2].coerceAtLeast(1)
                changed(pos)
            }
            T_SWIPE -> showFields(
                "Свайп", listOf("X начала", "Y начала", "X конца", "Y конца", "Время, мс"),
                listOf(s.x, s.y, s.x2, s.y2, s.ms), "Дубль", { duplicate(pos) }
            ) { v ->
                s.x = v[0]
                s.y = v[1]
                s.x2 = v[2]
                s.y2 = v[3]
                s.ms = v[4].coerceAtLeast(1)
                changed(pos)
            }
            T_WAIT -> showFields("Пауза", listOf("Миллисекунд"), listOf(s.ms), "Дубль", { duplicate(pos) }) { v ->
                s.ms = v[0].coerceAtLeast(1)
                changed(pos)
            }
            T_LOOP -> showFields("Цикл", listOf("Повторов (0 = бесконечно)"), listOf(s.n)) { v ->
                s.n = v[0].coerceAtLeast(0)
                changed(pos)
            }
            T_COLOR -> showFields(
                "Ждать цвет",
                listOf("X", "Y", "Допуск цвета, 0–255", "Таймаут, мс (0 = ждать вечно)"),
                listOf(s.x, s.y, if (s.n > 0) s.n else 30, s.ms), "Дубль", { duplicate(pos) }
            ) { v ->
                s.x = v[0]
                s.y = v[1]
                s.n = v[2].coerceIn(0, 255)
                s.ms = v[3].coerceAtLeast(0)
                changed(pos)
            }
            else -> {}
        }
    }

    private fun renameDialog() {
        askText("Название скрипта", script.name) { name ->
            script.name = name
            save()
            refreshHeader()
        }
    }

    private fun settingsDialog() {
        showFields(
            "Настройки скрипта",
            listOf("Повторов всего (0 = бесконечно)", "Разброс точки, px", "Разброс времени, %"),
            listOf(script.repeat, script.jitterPx, script.jitterPct)
        ) { v ->
            script.repeat = v[0].coerceAtLeast(0)
            script.jitterPx = v[1].coerceIn(0, 200)
            script.jitterPct = v[2].coerceIn(0, 100)
            save()
            refreshHeader()
        }
    }

    private fun depthAt(pos: Int): Int {
        var d = 0
        for (i in 0 until pos) {
            val t = script.steps[i].type
            if (t == T_LOOP) d++ else if (t == T_END && d > 0) d--
        }
        val self = script.steps[pos].type
        return if (self == T_END && d > 0) d - 1 else d
    }

    inner class StepAdapter : RecyclerView.Adapter<StepAdapter.VH>() {

        inner class VH(
            val row: LinearLayout, val idx: TextView, val badge: TextView, val desc: TextView
        ) : RecyclerView.ViewHolder(row)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val row = LinearLayout(this@EditorActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = roundBg(CARD, dp(16).toFloat())
            row.setPadding(dp(12), dp(12), dp(14), dp(12))
            val lp = RecyclerView.LayoutParams(-1, -2)
            lp.bottomMargin = dp(8)
            row.layoutParams = lp

            val idx = txt("", 13f, MUTED)
            idx.gravity = Gravity.CENTER
            row.addView(idx, LinearLayout.LayoutParams(dp(26), -2))

            val badge = txt("", 12f, BG, true)
            badge.gravity = Gravity.CENTER
            badge.setPadding(dp(8), dp(5), dp(8), dp(5))
            val bl = LinearLayout.LayoutParams(dp(68), -2)
            bl.marginStart = dp(4)
            row.addView(badge, bl)

            val desc = txt("", 14f, Color.WHITE)
            desc.setPadding(dp(12), 0, 0, 0)
            row.addView(desc, LinearLayout.LayoutParams(0, -2, 1f))
            return VH(row, idx, badge, desc)
        }

        override fun getItemCount(): Int = script.steps.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val s = script.steps[position]
            h.idx.text = (position + 1).toString()
            h.badge.text = s.label()
            h.badge.background = roundBg(s.badgeColor(), dp(10).toFloat())
            h.desc.text = s.describe()
            val lp = h.row.layoutParams as RecyclerView.LayoutParams
            lp.marginStart = dp(14 * depthAt(position))
            h.row.layoutParams = lp
            h.row.pressable {
                val p = h.adapterPosition
                if (p >= 0) editStep(p)
            }
        }
    }
}
