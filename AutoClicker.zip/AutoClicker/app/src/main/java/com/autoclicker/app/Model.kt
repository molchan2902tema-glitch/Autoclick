package com.autoclicker.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

const val T_TAP = "tap"
const val T_HOLD = "hold"
const val T_SWIPE = "swipe"
const val T_WAIT = "wait"
const val T_LOOP = "loop"
const val T_END = "end"
const val T_COLOR = "color"

class Step(
    var type: String,
    var x: Int = 0,
    var y: Int = 0,
    var x2: Int = 0,
    var y2: Int = 0,
    var ms: Int = 0,
    var n: Int = 0,
    var color: Int = 0
) {
    fun copyStep(): Step = Step(type, x, y, x2, y2, ms, n, color)

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("t", type)
        o.put("x", x)
        o.put("y", y)
        o.put("x2", x2)
        o.put("y2", y2)
        o.put("ms", ms)
        o.put("n", n)
        o.put("c", color)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Step = Step(
            o.optString("t", T_TAP), o.optInt("x"), o.optInt("y"),
            o.optInt("x2"), o.optInt("y2"), o.optInt("ms"), o.optInt("n"), o.optInt("c")
        )
    }
}

class Script(
    var id: Long,
    var name: String,
    var repeat: Int = 1,
    var jitterPx: Int = 0,
    var jitterPct: Int = 0,
    val steps: MutableList<Step> = ArrayList()
)

fun Step.label(): String = when (type) {
    T_TAP -> "Тап"
    T_HOLD -> "Удерж."
    T_SWIPE -> "Свайп"
    T_WAIT -> "Пауза"
    T_LOOP -> "Цикл"
    T_END -> "Конец"
    T_COLOR -> "Цвет"
    else -> type
}

fun Step.badgeColor(): Int = when (type) {
    T_TAP -> 0xFF3DDC84.toInt()
    T_HOLD -> 0xFF2DD4BF.toInt()
    T_SWIPE -> 0xFF60A5FA.toInt()
    T_WAIT -> 0xFFFBBF24.toInt()
    T_LOOP, T_END -> 0xFFC084FC.toInt()
    T_COLOR -> 0xFFF472B6.toInt()
    else -> 0xFF8A93A3.toInt()
}

fun Step.describe(): String = when (type) {
    T_TAP -> "$x, $y"
    T_HOLD -> "$x, $y · $ms мс"
    T_SWIPE -> "$x, $y → $x2, $y2 · $ms мс"
    T_WAIT -> "$ms мс"
    T_LOOP -> if (n <= 0) "Повторять бесконечно" else "Повторить $n раз"
    T_END -> "Конец цикла"
    T_COLOR -> "$x, $y · " + String.format("#%06X", color and 0xFFFFFF) +
        if (ms > 0) " · до $ms мс" else " · ждать"
    else -> ""
}

object Store {
    private const val KEY = "scripts"

    fun load(c: Context): MutableList<Script> {
        val out = ArrayList<Script>()
        val raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val s = Script(
                    o.optLong("id"), o.optString("name", "Скрипт"),
                    o.optInt("repeat", 1), o.optInt("jpx"), o.optInt("jpct")
                )
                val st = o.optJSONArray("steps")
                if (st != null) {
                    for (j in 0 until st.length()) s.steps.add(Step.fromJson(st.getJSONObject(j)))
                }
                out.add(s)
            }
        } catch (e: Exception) {
            // повреждённые данные игнорируем
        }
        return out
    }

    fun save(c: Context, list: List<Script>) {
        val arr = JSONArray()
        for (s in list) {
            val o = JSONObject()
            o.put("id", s.id)
            o.put("name", s.name)
            o.put("repeat", s.repeat)
            o.put("jpx", s.jitterPx)
            o.put("jpct", s.jitterPct)
            val st = JSONArray()
            for (step in s.steps) st.put(step.toJson())
            o.put("steps", st)
            arr.put(o)
        }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun get(c: Context, id: Long): Script? {
        for (s in load(c)) if (s.id == id) return s
        return null
    }

    fun update(c: Context, id: Long, fn: (Script) -> Unit) {
        val l = load(c)
        for (s in l) {
            if (s.id == id) {
                fn(s)
                save(c, l)
                return
            }
        }
    }

    fun create(c: Context, name: String): Script {
        val l = load(c)
        val s = Script(System.currentTimeMillis(), name)
        l.add(s)
        save(c, l)
        return s
    }

    fun delete(c: Context, id: Long) {
        val l = load(c)
        l.removeAll { it.id == id }
        save(c, l)
    }
}
