package com.autoclicker.app

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.util.Locale
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var dot: View
    private lateinit var status: TextView
    private lateinit var valueTv: TextView
    private lateinit var rateTv: TextView
    private lateinit var hint: TextView
    private lateinit var button: TextView
    private lateinit var seek: SeekBar
    private var pulse: ValueAnimator? = null

    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this).apply { setBackgroundColor(BG) }
        setContentView(root)

        content = buildContent()
        content.alpha = 0f
        content.translationY = dp(24).toFloat()
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        val splash = buildSplash()
        root.addView(splash, FrameLayout.LayoutParams(-1, -1))

        refresh()
        splash.postDelayed({
            content.animate().alpha(1f).translationY(0f).setDuration(450).start()
            splash.animate().alpha(0f).setDuration(350).withEndAction {
                pulse?.cancel()
                root.removeView(splash)
            }.start()
        }, 900)
    }

    override fun onResume() {
        super.onResume()
        if (::button.isInitialized) refresh()
    }

    override fun onDestroy() {
        pulse?.cancel()
        super.onDestroy()
    }

    private fun tv(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun buildSplash(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setBackgroundColor(BG)
        isClickable = true
        val icon = IconView(context, IconView.Kind.TARGET, ACCENT)
        addView(icon, LinearLayout.LayoutParams(dp(96), dp(96)))
        addView(tv("Автокликер", 20f, Color.WHITE, true).apply { setPadding(0, dp(20), 0, 0) })
        pulse = ValueAnimator.ofFloat(1f, 1.12f).apply {
            duration = 600
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { icon.scaleX = it.animatedValue as Float; icon.scaleY = it.animatedValue as Float }
            start()
        }
    }

    private fun buildContent(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(24), dp(56), dp(24), dp(32))

        addView(tv("Автокликер", 30f, Color.WHITE, true))

        val statusRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        dot = View(context)
        statusRow.addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginEnd = dp(8) })
        status = tv("", 15f, MUTED)
        statusRow.addView(status)
        addView(statusRow)

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(CARD, dp(24).toFloat())
            setPadding(dp(22), dp(20), dp(22), dp(20))
        }
        card.addView(tv("Интервал между кликами", 14f, MUTED))
        valueTv = tv("", 40f, Color.WHITE, true)
        card.addView(valueTv)
        rateTv = tv("", 14f, ACCENT)
        card.addView(rateTv)

        seek = SeekBar(context).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(ACCENT)
            thumbTintList = ColorStateList.valueOf(ACCENT)
            progressBackgroundTintList = ColorStateList.valueOf(0xFF2A303B.toInt())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    val ms = toMs(p)
                    if (fromUser) prefs.edit().putInt(KEY_INTERVAL, ms).apply()
                    showInterval(ms)
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        card.addView(seek, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(32) })

        addView(View(context), LinearLayout.LayoutParams(-1, 0, 1f))

        hint = tv("", 14f, MUTED).apply { gravity = Gravity.CENTER }
        addView(hint, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        button = tv("", 17f, 0xFF06210F.toInt(), true).apply {
            gravity = Gravity.CENTER
            background = roundBg(ACCENT, dp(29).toFloat())
            pressable { onMainButton() }
        }
        addView(button, LinearLayout.LayoutParams(-1, dp(58)))

        seek.progress = toProgress(prefs.getInt(KEY_INTERVAL, 500))
        showInterval(toMs(seek.progress))
    }

    private fun toMs(p: Int) = (50.0 * 100.0.pow(p / 100.0)).roundToInt()
    private fun toProgress(ms: Int) =
        (ln(ms.coerceAtLeast(50) / 50.0) / ln(100.0) * 100).roundToInt().coerceIn(0, 100)

    private fun showInterval(ms: Int) {
        val ru = Locale("ru")
        valueTv.text = if (ms < 1000) "$ms мс" else String.format(ru, "%.1f с", ms / 1000.0)
        val r = 1000.0 / ms
        rateTv.text = "≈ " + String.format(ru, if (r >= 10) "%.0f" else "%.1f", r) + " кл/с"
    }

    private fun onMainButton() {
        val svc = ClickerService.instance
        when {
            svc == null -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            !svc.isPanelVisible -> {
                svc.showPanel()
                refresh()
                moveTaskToBack(true)
            }
            else -> {
                svc.hidePanel()
                refresh()
            }
        }
    }

    private fun refresh() {
        val svc = ClickerService.instance
        val s: String; val c: Int; val h: String; val b: String
        when {
            svc == null -> {
                s = "Служба выключена"; c = MUTED
                h = "Откройте настройки и включите «Автокликер» в службах специальных возможностей."
                b = "Включить службу"
            }
            !svc.isPanelVisible -> {
                s = "Готов к работе"; c = ACCENT
                h = "Перетащите мишень в нужное место и нажмите старт на панели."
                b = "Показать панель"
            }
            else -> {
                s = "Панель активна"; c = ACCENT
                h = "Кликер работает в фоне. Управляйте им с панели."
                b = "Скрыть панель"
            }
        }
        status.text = s
        dot.background = ovalBg(c)
        hint.text = h
        button.text = b
    }
}
