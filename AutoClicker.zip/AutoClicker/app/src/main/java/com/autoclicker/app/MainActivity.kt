package com.autoclicker.app

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var content: View
    private lateinit var statusDot: View
    private lateinit var statusTv: TextView
    private lateinit var valueTv: TextView
    private lateinit var rateTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var list: LinearLayout
    private var pulse: ValueAnimator? = null
    private var ready = false

    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        root.setBackgroundColor(BG)
        setContentView(root)

        content = buildContent()
        content.alpha = 0f
        content.translationY = dp(24).toFloat()
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        val splash = buildSplash()
        root.addView(splash, FrameLayout.LayoutParams(-1, -1))

        ready = true
        refresh()
        splash.postDelayed({
            content.animate().alpha(1f).translationY(0f).setDuration(450).start()
            splash.animate().alpha(0f).setDuration(350).withEndAction {
                pulse?.cancel()
                root.removeView(splash)
            }.start()
        }, 900L)
    }

    override fun onResume() {
        super.onResume()
        if (ready) refresh()
    }

    override fun onDestroy() {
        pulse?.cancel()
        super.onDestroy()
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    private fun buildSplash(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setBackgroundColor(BG)
        box.isClickable = true
        val icon = IconView(this, IconView.Kind.TARGET, ACCENT)
        box.addView(icon, LinearLayout.LayoutParams(dp(96), dp(96)))
        val t = txt("Автокликер", 20f, Color.WHITE, true)
        t.setPadding(0, dp(20), 0, 0)
        box.addView(t)
        val a = ValueAnimator.ofFloat(1f, 1.12f)
        a.duration = 600
        a.repeatMode = ValueAnimator.REVERSE
        a.repeatCount = ValueAnimator.INFINITE
        a.addUpdateListener {
            val v = it.animatedValue as Float
            icon.scaleX = v
            icon.scaleY = v
        }
        a.start()
        pulse = a
        return box
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundBg(CARD, dp(24).toFloat())
        c.setPadding(dp(20), dp(18), dp(20), dp(18))
        return c
    }

    private fun buildContent(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(52), dp(20), dp(32))

        col.addView(txt("Автокликер", 30f, Color.WHITE, true))

        // статус службы
        val statusRow = LinearLayout(this)
        statusRow.orientation = LinearLayout.HORIZONTAL
        statusRow.gravity = Gravity.CENTER_VERTICAL
        statusRow.setPadding(0, dp(10), 0, dp(10))
        statusDot = View(this)
        val dotLp = LinearLayout.LayoutParams(dp(8), dp(8))
        dotLp.marginEnd = dp(8)
        statusRow.addView(statusDot, dotLp)
        statusTv = txt("", 15f, MUTED)
        statusRow.addView(statusTv)
        statusRow.pressable {
            if (ClickerService.instance == null) openAccessibility()
        }
        col.addView(statusRow)

        // быстрый клик
        val quick = card()
        quick.addView(txt("Быстрый клик", 14f, MUTED))
        valueTv = txt("", 40f, Color.WHITE, true)
        valueTv.pressable { editInterval() }
        quick.addView(valueTv)
        rateTv = txt("", 14f, ACCENT)
        quick.addView(rateTv)

        seek = SeekBar(this)
        seek.max = 1000
        seek.progressTintList = ColorStateList.valueOf(ACCENT)
        seek.thumbTintList = ColorStateList.valueOf(ACCENT)
        seek.progressBackgroundTintList = ColorStateList.valueOf(0xFF2A303B.toInt())
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                val ms = toMs(p)
                if (fromUser) prefs.edit().putInt(KEY_INTERVAL, ms).apply()
                showInterval(ms)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        val seekLp = LinearLayout.LayoutParams(-1, -2)
        seekLp.topMargin = dp(14)
        quick.addView(seek, seekLp)

        val hint = txt("Нажмите на число, чтобы ввести точное значение, 1–1000 мс", 12f, MUTED)
        hint.setPadding(0, dp(6), 0, 0)
        quick.addView(hint)

        val go = pill("Запустить", ONACCENT, ACCENT, 54)
        go.textSize = 17f
        go.pressable { startQuick() }
        val goLp = LinearLayout.LayoutParams(-1, dp(54))
        goLp.topMargin = dp(18)
        quick.addView(go, goLp)

        val quickLp = LinearLayout.LayoutParams(-1, -2)
        quickLp.topMargin = dp(8)
        col.addView(quick, quickLp)

        // скрипты
        val head = txt("Скрипты", 14f, MUTED)
        head.setPadding(dp(4), dp(28), 0, dp(10))
        col.addView(head)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)

        val newBtn = pill("Новый скрипт", ACCENT, CARD, 52)
        newBtn.pressable { newScript() }
        val nbLp = LinearLayout.LayoutParams(-1, dp(52))
        nbLp.topMargin = dp(4)
        col.addView(newBtn, nbLp)

        // координаты
        val tool = card()
        tool.addView(txt("Координаты касаний", 16f, Color.WHITE, true))
        val td = txt("Показывает X, Y под пальцем и копирует их в буфер обмена", 13f, MUTED)
        td.setPadding(0, dp(4), 0, 0)
        tool.addView(td)
        tool.pressable { startMonitor() }
        val toolLp = LinearLayout.LayoutParams(-1, -2)
        toolLp.topMargin = dp(20)
        col.addView(tool, toolLp)

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.addView(col)
        return sv
    }

    private fun toMs(p: Int): Int = 1000.0.pow(p / 1000.0).roundToInt().coerceIn(1, 1000)

    private fun toProgress(ms: Int): Int =
        (ln(ms.coerceIn(1, 1000).toDouble()) / ln(1000.0) * 1000.0).roundToInt().coerceIn(0, 1000)

    private fun showInterval(ms: Int) {
        valueTv.text = "$ms мс"
        val r = 1000.0 / ms
        val ru = Locale("ru")
        rateTv.text = "≈ " + String.format(ru, if (r >= 10) "%.0f" else "%.1f", r) + " кл/с"
    }

    private fun editInterval() {
        val cur = prefs.getInt(KEY_INTERVAL, 100).coerceIn(1, 1000)
        showFields("Интервал, мс", listOf("От 1 до 1000"), listOf(cur)) { v ->
            val ms = v[0].coerceIn(1, 1000)
            prefs.edit().putInt(KEY_INTERVAL, ms).apply()
            seek.progress = toProgress(ms)
            showInterval(ms)
        }
    }

    private fun openAccessibility() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
            toast("Откройте настройки специальных возможностей вручную")
        }
    }

    private fun startQuick() {
        val svc = ClickerService.instance
        if (svc == null) {
            toast("Включите службу «Автокликер»")
            openAccessibility()
            return
        }
        svc.showQuickPanel()
        moveTaskToBack(true)
    }

    private fun startMonitor() {
        val svc = ClickerService.instance
        if (svc == null) {
            toast("Включите службу «Автокликер»")
            openAccessibility()
            return
        }
        svc.startMonitor()
        moveTaskToBack(true)
    }

    private fun newScript() {
        val n = Store.load(this).size + 1
        askText("Название скрипта", "Скрипт $n") { name ->
            val s = Store.create(this, name)
            openEditor(s.id)
        }
    }

    private fun openEditor(id: Long) {
        val i = Intent(this, EditorActivity::class.java)
        i.putExtra("id", id)
        startActivity(i)
        overridePendingTransition(R.anim.enter, R.anim.exit)
    }

    private fun refresh() {
        val svc = ClickerService.instance
        if (svc == null) {
            statusTv.text = "Служба выключена · нажмите, чтобы включить"
            statusDot.background = ovalBg(DANGER)
        } else {
            statusTv.text = "Служба включена"
            statusDot.background = ovalBg(ACCENT)
        }
        val ms = prefs.getInt(KEY_INTERVAL, 100).coerceIn(1, 1000)
        seek.progress = toProgress(ms)
        showInterval(ms)

        list.removeAllViews()
        val scripts = Store.load(this)
        for (s in scripts) {
            val c = card()
            c.addView(txt(s.name, 17f, Color.WHITE, true))
            val rep = if (s.repeat == 0) "∞" else s.repeat.toString()
            val sub = txt("${s.steps.size} шагов · повтор $rep", 13f, MUTED)
            sub.setPadding(0, dp(2), 0, 0)
            c.addView(sub)
            c.pressable(onLong = {
                confirmDialog("Удалить скрипт?", s.name, "Удалить") {
                    Store.delete(this, s.id)
                    refresh()
                }
            }) { openEditor(s.id) }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(8)
            list.addView(c, lp)
        }
    }
}
