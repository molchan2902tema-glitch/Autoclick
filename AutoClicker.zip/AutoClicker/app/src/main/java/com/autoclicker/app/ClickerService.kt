package com.autoclicker.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout

class ClickerService : AccessibilityService() {

    companion object {
        var instance: ClickerService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var target: IconView? = null
    private var targetLp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var play: IconView? = null
    private var running = false

    val isPanelVisible: Boolean get() = panel != null

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            click()
            handler.postDelayed(this, intervalMs().toLong())
        }
    }

    private fun intervalMs(): Int =
        getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_INTERVAL, 500).coerceAtLeast(30)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() { setRunning(false) }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        hidePanel()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hidePanel()
        instance = null
        super.onDestroy()
    }

    private fun click() {
        val t = target ?: return
        val loc = IntArray(2)
        t.getLocationOnScreen(loc)
        val x = loc[0] + t.width / 2f
        val y = loc[1] + t.height / 2f
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 10))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun setRunning(r: Boolean) {
        running = r
        handler.removeCallbacks(tick)
        val t = target
        val tl = targetLp
        if (t != null && tl != null) {
            tl.flags = if (r) tl.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            else tl.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            t.animate().alpha(if (r) .45f else 1f).setDuration(200).start()
            runCatching { wm?.updateViewLayout(t, tl) }
        }
        play?.let {
            it.kind = if (r) IconView.Kind.PAUSE else IconView.Kind.PLAY
            it.background = ovalBg(if (r) DANGER else ACCENT)
            it.invalidate()
        }
        if (r) handler.postDelayed(tick, 300)
    }

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    @Suppress("ClickableViewAccessibility")
    private fun makeDraggable(handle: View, lp: WindowManager.LayoutParams, host: View) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    runCatching { wm?.updateViewLayout(host, lp) }
                }
            }
            true
        }
    }

    fun showPanel() {
        if (panel != null) return
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val d = resources.displayMetrics

        // Мишень
        val t = IconView(this, IconView.Kind.TARGET, ACCENT)
        val tl = params(dp(64), dp(64)).apply {
            x = d.widthPixels / 2 - dp(32)
            y = d.heightPixels / 2 - dp(32)
        }
        makeDraggable(t, tl, t)
        manager.addView(t, tl)
        target = t; targetLp = tl

        // Панель управления
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundBg(0xE61A1F29.toInt(), dp(32).toFloat())
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        val grip = IconView(this, IconView.Kind.GRIP, MUTED)
        row.addView(grip, LinearLayout.LayoutParams(dp(28), dp(52)))

        val p = IconView(this, IconView.Kind.PLAY, Color.WHITE).apply {
            background = ovalBg(ACCENT)
            pressable { setRunning(!running) }
        }
        row.addView(p, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginStart = dp(4) })

        val close = IconView(this, IconView.Kind.CLOSE, MUTED).apply {
            pressable { hidePanel() }
        }
        row.addView(close, LinearLayout.LayoutParams(dp(44), dp(52)))

        val pl = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            x = dp(24)
            y = d.heightPixels - dp(220)
        }
        makeDraggable(grip, pl, row)
        manager.addView(row, pl)
        panel = row; play = p
    }

    fun hidePanel() {
        setRunning(false)
        target?.let { v -> runCatching { wm?.removeView(v) } }
        panel?.let { v -> runCatching { wm?.removeView(v) } }
        target = null; targetLp = null; panel = null; play = null
    }
}
