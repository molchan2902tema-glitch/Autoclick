package com.autoclicker.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.random.Random

class ClickerService : AccessibilityService() {

    companion object {
        var instance: ClickerService? = null
        private const val STEP_GAP = 25L
    }

    private class Hud(val root: View, val play: IconView?, val label: TextView?)

    private val handler = Handler(Looper.getMainLooper())
    private val windowManager: WindowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val added = ArrayList<View>()

    private var target: IconView? = null
    private var targetLp: WindowManager.LayoutParams? = null
    private var hud: Hud? = null
    private var overlay: PickView? = null
    private var overlayLp: WindowManager.LayoutParams? = null

    // быстрый режим
    private var quickRunning = false
    private var qx = 0f
    private var qy = 0f
    private var qInterval = 100L
    private var nextAt = 0L

    // скрипт
    private var script: Script? = null
    private var scriptRunning = false
    private var started = false
    private var countdown = 0
    private var pc = 0
    private var iter = 0
    private val frames = ArrayList<IntArray>()
    private var colorStart = 0L

    // сессии выбора точки / записи / координат
    private var sessionMode = ""
    private var sessionKind = ""
    private var sessionScript = 0L
    private var sessionActive = false
    private var recCount = 0
    private var lastUp = 0L
    private var lastCoords = "Коснитесь экрана"

    private val quickTick = Runnable { fireQuick() }
    private val stepRunnable = Runnable { step() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        quickRunning = false
        scriptRunning = false
    }

    override fun onUnbind(intent: Intent?): Boolean {
        hideAll()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hideAll()
        instance = null
        super.onDestroy()
    }

    // ================= окна =================

    private fun params(w: Int, h: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        return lp
    }

    private fun addWindow(v: View, lp: WindowManager.LayoutParams) {
        windowManager.addView(v, lp)
        added.add(v)
    }

    @Suppress("ClickableViewAccessibility")
    private fun makeDraggable(handle: View, lp: WindowManager.LayoutParams, host: View) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    ox = lp.x
                    oy = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    try {
                        windowManager.updateViewLayout(host, lp)
                    } catch (ex: Exception) {
                    }
                }
            }
            true
        }
    }

    private fun addHud(
        label: String?, withPlay: Boolean,
        onPlay: () -> Unit, onClose: () -> Unit, x: Int, y: Int
    ): Hud {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = roundBg(0xE61A1F29.toInt(), dp(32).toFloat())
        row.setPadding(dp(6), dp(6), dp(6), dp(6))

        val grip = IconView(this, IconView.Kind.GRIP, MUTED)
        row.addView(grip, LinearLayout.LayoutParams(dp(28), dp(52)))

        var playView: IconView? = null
        if (withPlay) {
            val pv = IconView(this, IconView.Kind.PLAY, Color.WHITE)
            pv.background = ovalBg(ACCENT)
            pv.pressable { onPlay() }
            val plp = LinearLayout.LayoutParams(dp(52), dp(52))
            plp.marginStart = dp(4)
            row.addView(pv, plp)
            playView = pv
        }

        var labelView: TextView? = null
        if (label != null) {
            val lv = TextView(this)
            lv.text = label
            lv.setTextColor(Color.WHITE)
            lv.textSize = 14f
            lv.gravity = Gravity.CENTER_VERTICAL
            lv.minWidth = dp(150)
            lv.setPadding(dp(12), 0, dp(8), 0)
            row.addView(lv, LinearLayout.LayoutParams(-2, dp(52)))
            labelView = lv
        }

        val close = IconView(this, IconView.Kind.CLOSE, MUTED)
        close.pressable { onClose() }
        row.addView(close, LinearLayout.LayoutParams(dp(44), dp(52)))

        val lp = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        lp.x = x
        lp.y = y
        makeDraggable(grip, lp, row)
        addWindow(row, lp)
        return Hud(row, playView, labelView)
    }

    private fun setPlayState(h: Hud?, running: Boolean) {
        val p = h?.play ?: return
        p.kind = if (running) IconView.Kind.PAUSE else IconView.Kind.PLAY
        p.background = ovalBg(if (running) DANGER else ACCENT)
        p.invalidate()
    }

    fun hideAll() {
        quickRunning = false
        scriptRunning = false
        started = false
        handler.removeCallbacksAndMessages(null)
        for (v in added) {
            try {
                windowManager.removeView(v)
            } catch (e: Exception) {
            }
        }
        added.clear()
        target = null
        targetLp = null
        hud = null
        overlay = null
        overlayLp = null
        script = null
        sessionMode = ""
        sessionActive = false
    }

    private fun openApp(cls: Class<*>, id: Long) {
        try {
            val i = Intent(this, cls)
            i.putExtra("id", id)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    // ================= жесты =================

    private fun tapGesture(x: Float, y: Float, dur: Long): GestureDescription {
        val p = Path()
        p.moveTo(maxOf(x, 0f), maxOf(y, 0f))
        val st = GestureDescription.StrokeDescription(p, 0L, dur.coerceIn(1L, 59000L))
        return GestureDescription.Builder().addStroke(st).build()
    }

    private fun swipeGesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): GestureDescription {
        val p = Path()
        p.moveTo(maxOf(x1, 0f), maxOf(y1, 0f))
        p.lineTo(maxOf(x2, 0f), maxOf(y2, 0f))
        val st = GestureDescription.StrokeDescription(p, 0L, dur.coerceIn(1L, 59000L))
        return GestureDescription.Builder().addStroke(st).build()
    }

    private fun fire(g: GestureDescription) {
        dispatchGesture(g, null, null)
    }

    private fun round10(v: Long): Int = ((v + 5L) / 10L * 10L).toInt()

    // ================= быстрый режим =================

    fun showQuickPanel() {
        hideAll()
        val d = resources.displayMetrics
        val t = IconView(this, IconView.Kind.TARGET, ACCENT)
        val tl = params(dp(64), dp(64))
        tl.x = d.widthPixels / 2 - dp(32)
        tl.y = d.heightPixels / 2 - dp(32)
        makeDraggable(t, tl, t)
        addWindow(t, tl)
        target = t
        targetLp = tl
        hud = addHud(null, true, { toggleQuick() }, { hideAll() }, dp(24), d.heightPixels - dp(220))
    }

    private fun setTargetTouchable(touchable: Boolean) {
        val t = target ?: return
        val tl = targetLp ?: return
        tl.flags = if (touchable) tl.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else tl.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        t.animate().alpha(if (touchable) 1f else .45f).setDuration(200).start()
        try {
            windowManager.updateViewLayout(t, tl)
        } catch (e: Exception) {
        }
    }

    private fun toggleQuick() {
        if (quickRunning) {
            quickRunning = false
            handler.removeCallbacks(quickTick)
            setTargetTouchable(true)
            setPlayState(hud, false)
        } else {
            val t = target ?: return
            val loc = IntArray(2)
            t.getLocationOnScreen(loc)
            qx = loc[0] + t.width / 2f
            qy = loc[1] + t.height / 2f
            qInterval = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_INTERVAL, 100).coerceIn(1, 1000).toLong()
            quickRunning = true
            setTargetTouchable(false)
            setPlayState(hud, true)
            nextAt = SystemClock.uptimeMillis() + 250L
            handler.postAtTime(quickTick, nextAt)
        }
    }

    private fun fireQuick() {
        if (!quickRunning) return
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                nextQuick()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                nextQuick()
            }
        }
        if (!dispatchGesture(tapGesture(qx, qy, 5L), cb, handler)) nextQuick()
    }

    private fun nextQuick() {
        if (!quickRunning) return
        nextAt += qInterval
        val now = SystemClock.uptimeMillis()
        if (nextAt < now) nextAt = now
        handler.postAtTime(quickTick, nextAt)
    }

    // ================= скрипты =================

    fun runScript(id: Long) {
        hideAll()
        val sc = Store.get(this, id) ?: return
        script = sc
        val d = resources.displayMetrics
        hud = addHud("Старт через 3", true, { toggleScript() }, { hideAll() }, dp(24), d.heightPixels - dp(220))
        setPlayState(hud, true)
        pc = 0
        iter = 0
        frames.clear()
        colorStart = 0L
        started = false
        scriptRunning = true
        countdown = 3
        tickCountdown()
    }

    private fun tickCountdown() {
        if (!scriptRunning) return
        if (countdown <= 0) {
            started = true
            updateHud()
            step()
            return
        }
        hud?.label?.text = "Старт через $countdown"
        countdown--
        handler.postDelayed({ tickCountdown() }, 1000L)
    }

    private fun toggleScript() {
        if (script == null) return
        if (scriptRunning) {
            scriptRunning = false
            handler.removeCallbacksAndMessages(null)
            setPlayState(hud, false)
            hud?.label?.text = "Пауза"
        } else {
            scriptRunning = true
            setPlayState(hud, true)
            if (!started) {
                pc = 0
                iter = 0
                frames.clear()
                countdown = 3
                tickCountdown()
            } else {
                updateHud()
                step()
            }
        }
    }

    private fun finishScript() {
        scriptRunning = false
        started = false
        handler.removeCallbacksAndMessages(null)
        setPlayState(hud, false)
        hud?.label?.text = "Готово"
    }

    private fun updateHud() {
        val sc = script ?: return
        val rep = if (sc.repeat == 0) "" else "/" + sc.repeat
        val cur = minOf(pc + 1, sc.steps.size)
        hud?.label?.text = "Шаг $cur/${sc.steps.size} · круг ${iter + 1}$rep"
    }

    private fun after(ms: Long) {
        handler.postDelayed(stepRunnable, maxOf(ms, 1L))
    }

    private fun jp(v: Int, sc: Script): Float {
        val j = if (sc.jitterPx > 0) Random.nextInt(-sc.jitterPx, sc.jitterPx + 1) else 0
        return (v + j).toFloat()
    }

    private fun jt(ms: Long, sc: Script): Long {
        if (sc.jitterPct <= 0) return ms
        val d = ms * sc.jitterPct / 100L
        return maxOf(0L, ms + Random.nextLong(-d, d + 1L))
    }

    private fun endLoop() {
        if (frames.isEmpty()) {
            pc++
            return
        }
        val f = frames[frames.size - 1]
        if (f[1] == -1 || f[1] > 1) {
            if (f[1] > 1) f[1] = f[1] - 1
            pc = f[0] + 1
        } else {
            frames.removeAt(frames.size - 1)
            pc++
        }
    }

    private fun step() {
        if (!scriptRunning) return
        val sc = script ?: return
        val steps = sc.steps
        if (pc >= steps.size) {
            if (frames.isNotEmpty()) {
                endLoop()
                after(1L)
                return
            }
            iter++
            if (steps.isEmpty() || (sc.repeat != 0 && iter >= sc.repeat)) {
                finishScript()
                return
            }
            pc = 0
            frames.clear()
            updateHud()
            after(STEP_GAP)
            return
        }
        val s = steps[pc]
        updateHud()
        when (s.type) {
            T_TAP -> {
                fire(tapGesture(jp(s.x, sc), jp(s.y, sc), 5L))
                pc++
                after(jt(STEP_GAP, sc))
            }
            T_HOLD -> {
                fire(tapGesture(jp(s.x, sc), jp(s.y, sc), s.ms.toLong()))
                pc++
                after(jt(s.ms.toLong() + STEP_GAP, sc))
            }
            T_SWIPE -> {
                fire(swipeGesture(jp(s.x, sc), jp(s.y, sc), jp(s.x2, sc), jp(s.y2, sc), s.ms.toLong()))
                pc++
                after(jt(s.ms.toLong() + STEP_GAP, sc))
            }
            T_WAIT -> {
                pc++
                after(jt(s.ms.toLong(), sc))
            }
            T_LOOP -> {
                frames.add(intArrayOf(pc, if (s.n <= 0) -1 else s.n))
                pc++
                after(1L)
            }
            T_END -> {
                endLoop()
                after(1L)
            }
            T_COLOR -> colorStep(s)
            else -> {
                pc++
                after(1L)
            }
        }
    }

    // ================= цвет пикселя (Android 11+) =================

    private fun near(a: Int, b: Int, tol: Int): Boolean =
        abs(Color.red(a) - Color.red(b)) <= tol &&
            abs(Color.green(a) - Color.green(b)) <= tol &&
            abs(Color.blue(a) - Color.blue(b)) <= tol

    private fun colorStep(s: Step) {
        if (Build.VERSION.SDK_INT < 30) {
            pc++
            after(1L)
            return
        }
        if (colorStart == 0L) colorStart = SystemClock.uptimeMillis()
        sampleColor(s.x, s.y) { c ->
            if (scriptRunning) {
                val ok = c != null && near(c, s.color, if (s.n > 0) s.n else 30)
                val timeout = s.ms > 0 && SystemClock.uptimeMillis() - colorStart > s.ms
                if (ok || timeout) {
                    colorStart = 0L
                    pc++
                    after(1L)
                } else {
                    after(350L)
                }
            }
        }
    }

    private fun sampleColor(x: Int, y: Int, cb: (Int?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) {
            cb(null)
            return
        }
        sampleColor30(x, y, cb)
    }

    private fun sampleColor30(x: Int, y: Int, cb: (Int?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                var px: Int? = null
                try {
                    val hb = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    if (bmp != null) {
                        px = bmp.getPixel(x.coerceIn(0, bmp.width - 1), y.coerceIn(0, bmp.height - 1))
                        bmp.recycle()
                    }
                    hw?.recycle()
                    hb.close()
                } catch (e: Exception) {
                    px = null
                }
                cb(px)
            }

            override fun onFailure(errorCode: Int) {
                cb(null)
            }
        })
    }

    // ================= выбор точки / запись / координаты =================

    fun startPickStep(id: Long, kind: String) {
        val hint = when (kind) {
            T_SWIPE -> "Проведите пальцем"
            T_HOLD -> "Нажмите и держите"
            else -> "Нажмите в нужной точке"
        }
        beginSession("pick", kind, id, kind == T_SWIPE, hint)
    }

    fun startRecord(id: Long) {
        beginSession("record", "", id, true, "Выполняйте действия")
    }

    fun startMonitor() {
        beginSession("monitor", "", 0L, false, "Касайтесь экрана")
    }

    private fun beginSession(mode: String, kind: String, id: Long, line: Boolean, hint: String) {
        hideAll()
        sessionMode = mode
        sessionKind = kind
        sessionScript = id
        recCount = 0
        lastUp = 0L
        sessionActive = false
        lastCoords = "Коснитесь экрана"

        val pv = PickView(this, line, hint) { r -> onSessionTouch(r) }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        addWindow(pv, lp)
        overlay = pv
        overlayLp = lp
        hud = addHud(sessionLabel(), true, { setSessionActive(!sessionActive) }, { endSession() }, dp(24), dp(56))
        setPlayState(hud, false)
    }

    private fun sessionLabel(): String {
        if (sessionMode == "record") {
            if (sessionActive) return "Запись · $recCount"
            return if (recCount > 0) "Пауза · $recCount" else "Откройте экран"
        }
        if (sessionMode == "monitor") {
            return if (sessionActive) lastCoords else "Откройте экран"
        }
        return if (sessionActive) "Выберите точку" else "Откройте экран"
    }

    private fun setOverlayTouchable(t: Boolean) {
        val v = overlay ?: return
        val lp = overlayLp ?: return
        lp.flags = if (t) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try {
            windowManager.updateViewLayout(v, lp)
        } catch (e: Exception) {
        }
    }

    private fun setSessionActive(a: Boolean) {
        sessionActive = a
        overlay?.active = a
        setOverlayTouchable(a)
        setPlayState(hud, a)
        hud?.label?.text = sessionLabel()
    }

    private fun endSession() {
        val id = sessionScript
        val mode = sessionMode
        hideAll()
        if (mode == "monitor") openApp(MainActivity::class.java, 0L) else openApp(EditorActivity::class.java, id)
    }

    private fun onSessionTouch(r: PickResult) {
        if (sessionMode == "monitor") {
            lastCoords = "${r.x2}, ${r.y2}"
            try {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("xy", "${r.x2}, ${r.y2}"))
                hud?.label?.text = "$lastCoords · скопировано"
            } catch (e: Exception) {
                hud?.label?.text = lastCoords
            }
        } else if (sessionMode == "record") {
            onRecorded(r)
        } else if (sessionMode == "pick") {
            onPicked(r)
        }
    }

    private fun finishPick(id: Long, s: Step?) {
        if (s != null) {
            Store.update(this, id) { it.steps.add(s) }
            Toast.makeText(this, "Шаг добавлен", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Не удалось взять цвет", Toast.LENGTH_SHORT).show()
        }
        hideAll()
        openApp(EditorActivity::class.java, id)
    }

    private fun onPicked(r: PickResult) {
        val id = sessionScript
        when (sessionKind) {
            T_TAP -> finishPick(id, Step(T_TAP, x = r.x2, y = r.y2))
            T_HOLD -> finishPick(id, Step(T_HOLD, x = r.x2, y = r.y2, ms = maxOf(300, round10(r.dur))))
            T_SWIPE -> finishPick(id, Step(T_SWIPE, r.x1, r.y1, r.x2, r.y2, maxOf(80, round10(r.dur))))
            T_COLOR -> {
                overlay?.hideMarks = true
                handler.postDelayed({
                    sampleColor(r.x2, r.y2) { c ->
                        if (c == null) finishPick(id, null)
                        else finishPick(id, Step(T_COLOR, x = r.x2, y = r.y2, color = c, n = 30))
                    }
                }, 250L)
            }
        }
    }

    private fun onRecorded(r: PickResult) {
        val list = ArrayList<Step>()
        if (lastUp != 0L) {
            val gap = r.t0 - lastUp
            if (gap >= 120L) list.add(Step(T_WAIT, ms = round10(gap)))
        }
        val dist = Math.hypot((r.x2 - r.x1).toDouble(), (r.y2 - r.y1).toDouble())
        val g: GestureDescription
        if (dist < dp(18)) {
            if (r.dur >= 500L) {
                list.add(Step(T_HOLD, x = r.x2, y = r.y2, ms = round10(r.dur)))
                g = tapGesture(r.x2.toFloat(), r.y2.toFloat(), r.dur)
            } else {
                list.add(Step(T_TAP, x = r.x2, y = r.y2))
                g = tapGesture(r.x2.toFloat(), r.y2.toFloat(), 5L)
            }
        } else {
            val dd = maxOf(80, round10(r.dur))
            list.add(Step(T_SWIPE, r.x1, r.y1, r.x2, r.y2, dd))
            g = swipeGesture(r.x1.toFloat(), r.y1.toFloat(), r.x2.toFloat(), r.y2.toFloat(), dd.toLong())
        }
        Store.update(this, sessionScript) { it.steps.addAll(list) }
        recCount++
        lastUp = r.t1
        hud?.label?.text = sessionLabel()

        // повторяем жест в приложении под слоем, слой на это время «прозрачен» для касаний
        setOverlayTouchable(false)
        val restore = Runnable { setOverlayTouchable(sessionActive) }
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                handler.post(restore)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                handler.post(restore)
            }
        }
        if (!dispatchGesture(g, cb, handler)) handler.post(restore)
        handler.postDelayed(restore, r.dur + 700L)
    }
}
